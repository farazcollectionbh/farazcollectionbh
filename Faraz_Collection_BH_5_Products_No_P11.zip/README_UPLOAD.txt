Faraz Collection BH — five-product website update

The first Hainoteko P11 Power Bank card and product-11.jpg have been removed.
The other five product images and the updated index.html are included.

GitHub Pages upload: extract this ZIP, then upload index.html and the five remaining product images together into the repository root (same folder as the existing index.html), and commit the changes.
